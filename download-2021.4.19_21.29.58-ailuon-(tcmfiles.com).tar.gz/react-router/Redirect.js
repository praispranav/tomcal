"use strict";
require("./warnAboutDeprecatedCJSRequire")("Redirect");
module.exports = require("./index.js").Redirect;
