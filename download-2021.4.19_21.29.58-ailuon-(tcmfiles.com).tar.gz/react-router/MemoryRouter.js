"use strict";
require("./warnAboutDeprecatedCJSRequire")("MemoryRouter");
module.exports = require("./index.js").MemoryRouter;
