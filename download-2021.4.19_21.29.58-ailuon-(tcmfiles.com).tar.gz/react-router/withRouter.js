"use strict";
require("./warnAboutDeprecatedCJSRequire")("withRouter");
module.exports = require("./index.js").withRouter;
