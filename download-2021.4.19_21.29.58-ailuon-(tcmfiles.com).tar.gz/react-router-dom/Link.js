"use strict";
require("./warnAboutDeprecatedCJSRequire")("Link");
module.exports = require("./index.js").Link;
